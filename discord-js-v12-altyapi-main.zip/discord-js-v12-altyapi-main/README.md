# discord-js-v12-altyapi
DiscordJS V12 Boş Altyapı
