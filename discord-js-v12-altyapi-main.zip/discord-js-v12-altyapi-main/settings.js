module.exports = {
  "token": "Botunuzun tokeni",
  "sahip": ["Kendi Discord ID'nizi buraya yazın."], 
  "prefix": "Botunuzun prefixi."
};